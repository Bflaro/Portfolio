import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import daos.CountryDao;
import entities.Country;
import daos.CityDao;
import entities.City;
import entities.Database;

//Brxton Flaro Assignment2

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Database Project!");

        //SQL Connection in Databse.java
        try (Connection connection = Database.getDataConnection();
                Statement statement = connection.createStatement();)
        {
            List<Country> countryList;
            List<Country> regionList;

            List<City> cityList;
            List<City> citiesByCountry;
            List<City> largeCity;
    //Country Quries
        //CountryDoa (Able to change Southern Europe to any Reigon within the database)
            CountryDao countryDao = new CountryDao(connection);
            countryList = countryDao.findAll();
            regionList = countryDao.findByRegion("Southern Europe");

        //CityDao (Can change USA in citiesByCountry to any country within the database)
            CityDao cityDao = new CityDao(connection);
            cityList = cityDao.findAll();
            citiesByCountry = cityDao.findByCountry("USA");
            largeCity = cityDao.findLargeCities();
             
        //insert statement
            Country insertCountry = new Country();
            insertCountry.setCode("QUE");
            insertCountry.setName("Quebec");
            insertCountry.setContinent("North America");
            insertCountry.setRegion("North America");
            insertCountry.setSurfaceArea(1668000);
            insertCountry.setIndepYear(2025);
            insertCountry.setPopulation(8400000);
            insertCountry.setLifeExpectancy(84);
            insertCountry.setGNP(4090000);
            insertCountry.setGNPOld(5980000);
            insertCountry.setLocalName("Québec");
            insertCountry.setGovernmentForm("Democracy");
            insertCountry.setHead("Prime Minister");
            insertCountry.setCapital(12);
            insertCountry.setCode2("QU");
            countryDao.insert(insertCountry);
        

        // update / find by id
            Country updateCountry = new Country();
            updateCountry = countryDao.findById("QUE");

            updateCountry.setLifeExpectancy(82);
            countryDao.update(updateCountry);

            System.out.println(updateCountry);

        //delete (Commented out for Saftey)
            //countryDao.delete("QUE");
           
        //All countries
            System.out.println("Countries printed:");
            for(Country country: countryList)
            {
                System.out.println(country);
            }
            //Search for Pakistan
            Country countryName = new Country();
            countryName = countryDao.findByName("Pakistan");
            System.out.println(countryName);

            //search by region
            for(Country country: regionList)
            {
                System.out.println(country);
            }


    //city Queries
        //Prints all cities
            System.out.println("Cities printed:");
            for(City city: cityList)
            {
                System.out.println(city);
            }
        // prints based on Country put above
            for(City city: citiesByCountry)
            {
                System.out.println(city);
            }

        //Looks for city by name
            City cityName = new City();
            cityName = cityDao.findByName("Orange");
            System.out.println(cityName);

        //Prints out a list of cities that have population sof at least one million people
            for(City city: largeCity)
            {
                System.out.println(city);
            }

        } 		
        catch(SQLException ex)
        {
            System.err.println("Exception: " + ex.getMessage());
        }	
    }
}
