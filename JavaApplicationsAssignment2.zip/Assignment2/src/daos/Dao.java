package daos;

import java.util.List;

//this dao is just the interface
//the base class for all specific daos we will make, 
//they will implement this interface, like a child class using a parent class

public interface Dao<T, PK> {       //T = (generic) type (of the entity/table), PK = datatype of PK
    //none of these are pre-made functions, we must define them based on the sql code we want
    List<T> findAll();    //returns a list of the type of entity passed in
    T findById(PK pk);
    void insert(T item);
    Boolean update(T item);
    Boolean delete(PK pk);
}
