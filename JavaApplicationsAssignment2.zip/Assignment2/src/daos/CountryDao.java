package daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import entities.Country;

public class CountryDao implements Dao<Country, String> {
    Connection connection;
    

    public CountryDao(Connection connection) {
        this.connection = connection;
    }

//Finds all Countries and puts them in a list to be displayed
    public List<Country> findAll() {
        List <Country> countries = new ArrayList<>(); 
        
        try(Statement statement = connection.createStatement())
        {
            ResultSet result = statement.executeQuery("SELECT * FROM country");
            while(result.next())
            {
                Country country = new Country();
                country.setCode(result.getString("Code"));
                country.setName(result.getString("Name"));
                country.setContinent(result.getString("Continent"));
                country.setRegion(result.getString("Region"));
                country.setSurfaceArea(result.getFloat("SurfaceArea"));
                country.setIndepYear(result.getInt("IndepYear"));
                country.setPopulation(result.getInt("Population"));
                country.setLifeExpectancy(result.getFloat("LifeExpectancy"));
                country.setGNP(result.getFloat("GNP"));
                country.setGNPOld(result.getFloat("GNPOld"));
                country.setLocalName(result.getString("LocalName"));
                country.setGovernmentForm(result.getString("GovernmentForm"));
                country.setHead(result.getString("HeadOfState"));
                country.setCapital(result.getInt("Capital"));
                country.setCode2(result.getString("Code2"));
                countries.add(country);
            }
        }
        catch(SQLException e)
        {
            System.err.println(e.getMessage());
        }

        return countries;
    }

//Finds all Countries within a region and puts them in a list to be displayed
    public List<Country> findByRegion(String region) {
        List <Country> countries = new ArrayList<>(); 
        String selectCountry = "SELECT * FROM country WHERE Region=?";

        try(PreparedStatement ps = connection.prepareStatement(selectCountry);)
        {
            ps.setString(1, region);
            ResultSet result = ps.executeQuery();
            while(result.next())
            {
                Country country = new Country();
                country.setCode(result.getString("Code"));
                country.setName(result.getString("Name"));
                country.setContinent(result.getString("Continent"));
                country.setRegion(result.getString("Region"));
                country.setSurfaceArea(result.getFloat("SurfaceArea"));
                country.setIndepYear(result.getInt("IndepYear"));
                country.setPopulation(result.getInt("Population"));
                country.setLifeExpectancy(result.getFloat("LifeExpectancy"));
                country.setGNP(result.getFloat("GNP"));
                country.setGNPOld(result.getFloat("GNPOld"));
                country.setLocalName(result.getString("LocalName"));
                country.setGovernmentForm(result.getString("GovernmentForm"));
                country.setHead(result.getString("HeadOfState"));
                country.setCapital(result.getInt("Capital"));
                country.setCode2(result.getString("Code2"));
                countries.add(country);
            }
        }
        catch(SQLException e)
        {
            System.err.println(e.getMessage());
        }

        return countries;
    }

//Inserts a country into the table based on the information provided by the user
    public void insert(Country country) { 
    try(Statement statement = connection.createStatement())    {
        String insert = "INSERT INTO country VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        PreparedStatement ps = connection.prepareStatement(insert);
        ps.setString(1, country.getCode());
        ps.setString(2, country.getName());
        ps.setString(3, country.getContinent());
        ps.setString(4, country.getRegion());
        ps.setFloat(5, country.getSurfaceArea());
        ps.setInt(6, country.getIndepYear());
        ps.setInt(7, country.getPopulation());
        ps.setFloat(8, country.getLifeExpectancy());
        ps.setFloat(9, country.getGNP());
        ps.setFloat(10, country.getGNPOld());
        ps.setString(11, country.getLocalName());
        ps.setString(12, country.getGovernmentForm());
        ps.setString(13, country.getHead());
        ps.setInt(14, country.getCapital());
        ps.setString(15, country.getCode2());
        ps.executeUpdate();


    } catch (SQLException e) {
        System.err.println(e.getMessage());
    }
}

//Updates the life expectancy of an exsiting record
    public Boolean update(Country country) {
    Boolean success = true;
    String update = "UPDATE country SET LifeExpectancy=? WHERE Code=?";

    try(PreparedStatement ps = connection.prepareStatement(update);)
    {
        ps.setFloat(1,country.getLifeExpectancy());
        ps.setString(2, country.getCode());
        ps.executeUpdate();
    }
    catch(SQLException e)
    {
        System.err.println(e.getMessage());
        success = false;
    }
    return success;
}

//Finds and displays a Country based on the provided id
    public Country findById(String i) {
   Country country = new Country();
    String select = "SELECT * FROM country WHERE Code=?";

    try(PreparedStatement ps = connection.prepareStatement(select);)
    {
        ps.setString(1, i);
        ResultSet result = ps.executeQuery();

        if(result.next())
        {
            country.setCode(result.getString("Code"));
            country.setName(result.getString("Name"));
            country.setContinent(result.getString("Continent"));
            country.setRegion(result.getString("Region"));
            country.setSurfaceArea(result.getFloat("SurfaceArea"));
            country.setIndepYear(result.getInt("IndepYear"));
            country.setPopulation(result.getInt("Population"));
            country.setLifeExpectancy(result.getFloat("LifeExpectancy"));
            country.setGNP(result.getFloat("GNP"));
            country.setGNPOld(result.getFloat("GNPOld"));
            country.setLocalName(result.getString("LocalName"));
            country.setGovernmentForm(result.getString("GovernmentForm"));
            country.setHead(result.getString("HeadOfState"));
            country.setCapital(result.getInt("Capital"));
            country.setCode2(result.getString("Code2"));
        }
    }
    catch(SQLException e)
    {
        System.err.println(e.getMessage());
    }

    return country;
}

//Finds and displays a Country based on the provided name
    public Country findByName(String name) {
    Country country = new Country();
     String select = "SELECT * FROM country WHERE name=?";
 
     try(PreparedStatement ps = connection.prepareStatement(select);)
     {
         ps.setString(1, name);
         ResultSet result = ps.executeQuery();
 
         if(result.next())
         {
             country.setCode(result.getString("Code"));
             country.setName(result.getString("Name"));
             country.setContinent(result.getString("Continent"));
             country.setRegion(result.getString("Region"));
             country.setSurfaceArea(result.getFloat("SurfaceArea"));
             country.setIndepYear(result.getInt("IndepYear"));
             country.setPopulation(result.getInt("Population"));
             country.setLifeExpectancy(result.getFloat("LifeExpectancy"));
             country.setGNP(result.getFloat("GNP"));
             country.setGNPOld(result.getFloat("GNPOld"));
             country.setLocalName(result.getString("LocalName"));
             country.setGovernmentForm(result.getString("GovernmentForm"));
             country.setHead(result.getString("HeadOfState"));
             country.setCapital(result.getInt("Capital"));
             country.setCode2(result.getString("Code2"));
         }
     }
     catch(SQLException e)
     {
         System.err.println(e.getMessage());
     }
 
     return country;
 }

//deletes an existing record from the table
    public Boolean delete(String i) {
Boolean success = false;
String delete = "DELETE FROM country WHERE Code=?";

try(PreparedStatement ps = connection.prepareStatement(delete);)
{
    ps.setString(1, i);

    if(ps.executeUpdate() != 0)
    {
        success = true;
    }
}
catch(SQLException e)
{
    System.err.println(e.getMessage());
}
return success;
}

}
