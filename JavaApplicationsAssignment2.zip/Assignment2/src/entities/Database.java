package entities;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

//This class provides the connection details for using the database
public class Database {
    public static Connection getDataConnection() throws SQLException 
    {
        String protocol = "jdbc";
        String dbServer = "mysql";
        String host = "localhost";
        String port = "3306";
        String dbName = "world";

        String dbUrl = String.format("%s:%s://%s:%s/%s", protocol, dbServer, host, port, dbName);
        System.out.println(dbUrl);
        
        return DriverManager.getConnection(dbUrl, "root", "V0te2d@y");
    
    }
}

