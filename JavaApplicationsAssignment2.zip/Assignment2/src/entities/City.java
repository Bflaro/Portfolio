package entities;

//'city' table from world.sql 
public class City {
    //usually you should keep the same names here as the names of the table's column names in the database
    Integer ID;     //PK
    String Name;
    String CountryCode;
    String District;
    Integer Population;

    //getters and setters for the table, 'city'
    public Integer getID()
    {
        return ID;
    }

    public void setID(Integer ID)
    {
        this.ID = ID;
    }

    public String getName()
    {
        return Name;
    }

    public void setName(String name)
    {
        this.Name = name;
    }

    public String getCountryCode()
    {
        return CountryCode;
    }

    public void setCountryCode(String CountryCode)
    {
        this.CountryCode = CountryCode;
    }

    public String getDistrict()
    {
        return District;
    }

    public void setDistrict(String District)
    {
        this.District = District;
    }

    public Integer getPopulation()
    {
        return Population;
    }

    public void setPopulation(Integer Population)
    {
        this.Population = Population;
    } 

    @Override
    public String toString()
    {
        return "City -> ID: " + ID + ", Name: " + Name + ", CountryCode: " + CountryCode 
                + ", District: " + District + ", Population: " + Population;
    }
}
