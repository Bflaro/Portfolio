const express = require('express');
const app = express();
const mysql = require('mysql');
app.use(express.static("public"));

app.listen(3000);

app.get("/users", (request, response) => {
    let con = mysql.createConnection({
        host: "localhost",
        user: "airbnbUser",
        password: "comp206pw",
        database: "restaurants"
      });

    con.connect();
    
    let query = `SELECT name, city,country, cuisine FROM restaurants 
    ORDER BY restaurants.name ASC LIMIT ?,?`;

  
    let take = parseInt(request.query.take);
    let skip = parseInt(request.query.page) * take;

    query = mysql.format(query, [skip, take]);

    con.query(query, (error, result) => {
        response.json(result);
    });

    con.end();
});

app.get("/select", (request, response) => {
    let con = mysql.createConnection({
        host: "localhost",
        user: "airbnbUser",
        password: "comp206pw",
        database: "restaurants"
      });

    con.connect();
    
    let query = `SELECT * FROM restaurants ORDER BY name;`;    

    query = mysql.format(query);
    con.query(query, (error, result) => {
        response.json(result);
    });

    con.end();
});
