The following is a javascript project completed ny myself and Kael Moreira
in a group project.
The project is a database of resturant data, the goal was to make 
a table that could be veiwed with controls on per size and filters 
for the various columns.