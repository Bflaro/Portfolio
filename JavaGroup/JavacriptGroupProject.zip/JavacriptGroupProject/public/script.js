let table = document.querySelector("#main");
let dropDown = document.querySelector("#typeOfFilter");
let applyButton = document.querySelector('button#apply');

let tag = "", tagCheck, ctr=0;
let pageNumber = 0;
let take = 5;
let maxVal = 0;

function getData() 
{
    fetch(`/select`)
    .then(response => response.json())
    .then(data => {
        ctr=0;
        table.innerHTML = "";
        let resturantArray = [];
        for(let i = 0; i < data.length;i++) 
        {
            if(tag == "cuisine")
            {
                if(data[i].cuisine == tagCheck)
                {
                    resturantArray.push({
                        name: data[i].name,
                        city: data[i].city,
                      country: data[i].country,
                      cuisine: data[i].cuisine
                    });
                
                
                }
                
            }
            else if(tag == "country")
            {
                if(data[i].country == tagCheck)
                {
                    resturantArray.push({
                        name: data[i].name,
                        city: data[i].city,
                      country: data[i].country,
                      cuisine: data[i].cuisine
                    });
                }
            }
            else if(tag == "city")
            {
                if(data[i].city == tagCheck)
                {
                    resturantArray.push({
                        name: data[i].name,
                        city: data[i].city,
                      country: data[i].country,
                      cuisine: data[i].cuisine
                    });
                }
            }
            else
            {
                resturantArray.push({
                    name: data[i].name,
                    city: data[i].city,
                  country: data[i].country,
                  cuisine: data[i].cuisine
                });
                
                
            }
            
        }

        resturantArray.sort(
            function(a, b) {                
               return a.name > b.name ? 1 : -1;
            });
       
      maxVal = resturantArray.length;
        dataTwo(resturantArray);
        pageNum();
    });
}

function dataTwo (resturantArray)
{
    
    pageNum();
  table.innerHTML = "";
   for(let i = 0; i < take; i++) 
   {
    if (typeof resturantArray[i] !== 'undefined')
    
    {
        if(typeof resturantArray[i+(pageNumber*take)] !== 'undefined')
       {
            let row = table.insertRow(-1);
            let cell1 = row.insertCell(-1);
            let cell2 = row.insertCell(-1);
            let cell3 = row.insertCell(-1);
            let cell4 = row.insertCell(-1);
            cell1.innerHTML = resturantArray[i+(pageNumber*take)].name;
            cell2.innerHTML = resturantArray[i+(pageNumber*take)].city;
            cell3.innerHTML = resturantArray[i+(pageNumber*take)].country;
            cell4.innerHTML = resturantArray[i+(pageNumber*take)].cuisine;
            cell1.style="border: 1px solid";
            cell2.style="border: 1px solid";
            cell3.style="border: 1px solid";
            cell4.style="border: 1px solid";
       }
    }
      
  } 
  

}



function Param()
{
let filterArray = [];

fetch(`/select`)
    .then(response => response.json())
    .then(data => {
        dropDown.innerHTML = "";
        dropDown.innerHTML += `<option>No filter</option>`;
        for(let i = 0; i < data.length; i++) 
        {
            if(tag == "city")     
                filterArray.indexOf(data[i].city) === -1 ? filterArray.push(data[i].city) : console.log("already exists");    

            else if(tag == "country")
                filterArray.indexOf(data[i].country) === -1 ? filterArray.push(data[i].country) : console.log("already exists");

            else if(tag == "cuisine")
                filterArray.indexOf(data[i].cuisine) === -1 ? filterArray.push(data[i].cuisine) : console.log("already exists");
        }
        filterArray.sort();
        for(let i = 0; i < filterArray.length; i++) 
        {
            dropDown.innerHTML += `<option>${filterArray[i]}</option>`;  
        }
});
}

getData();
document.querySelector("#previous").addEventListener("click", event => {
    if(pageNumber > 0)
    {
    pageNumber--;
    getData();
    }
});

document.querySelector("#next").addEventListener("click", event => {
    if(((pageNumber+1)*take) <= maxVal)
    {
    pageNumber++;
    getData();
    }
});


document.querySelector("#perPage").addEventListener("change", event => {
    pageNumber=0;
    take = document.querySelector('#perPage option:checked').value;
    getData();  
});

function pageNum() {
    document.getElementById("pageN").innerHTML = "Displaying records: " + (((pageNumber+1)*take)-take+1) + "-"+ ((pageNumber+1)*take) + " of " + maxVal;
}   



document.querySelector("#filters").addEventListener("change", event => {
    tag = document.querySelector("#filters").value.toLowerCase();
    if(tag=="no filter"){tag = "";}
    Param();            
});

document.querySelector("#apply").addEventListener("click", event => {
    pageNumber=0;
    tagCheck = dropDown.value;
    if (tagCheck=="No filter")
    {
        alert("no filter selected");
    }
    else
        getData();  
});


document.querySelector("#revoke").addEventListener("click", event => {
   window.location.reload();
});