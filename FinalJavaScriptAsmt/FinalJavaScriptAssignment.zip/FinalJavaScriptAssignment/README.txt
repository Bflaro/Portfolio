The Following Project is the final assignmnet for the comp206
Javascript project.
I have written all ejs files as well as the main server.js file
the SQL file was provided