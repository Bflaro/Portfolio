const express = require('express');
const app = express();
const queries = require("./mysql/queries");
const mysql = require('mysql');
app.set('view engine', 'ejs');
app.listen(3000);

app.get('/', function(request, response) {
  let con = mysql.createConnection({
    host: "localhost",
    user: "airbnbUser",
    password: "comp206pw",
    database: "comp206_airbnb"
  });  

  con.connect();
  let query = `Select cities.name AS city, states.name AS state, states.id, cities.state_id
              FROM cities, states
              WHERE states.id = cities.state_id;`;
  let safeQuery = mysql.format(query);
  
  con.query(safeQuery, 
    (error, result) => {
  response.render('index', { title: 'Airbnb Search App', city: result});
con.end();
});
});


app.get('/airbnb', (request, response) => {
  let con = mysql.createConnection({
    host: "localhost",
    user: "airbnbUser",
    password: "comp206pw",
    database: "comp206_airbnb"
  });  

  con.connect();

  let query = `SELECT A.*, B.name as cityName, C.name as stateName, D.first_name, D.last_name, D.email
  FROM places A
  JOIN cities B on A.city_id = B.id
  JOIN states C on C.id = B.state_id
  JOIN users D ON A.user_id = D.id
  WHERE A.id = ?`;

  let id = request.query.id;

  con.query(query, [id],
    (error, result) => {
  response.render('searchedListing', { title:'AirBnb', listing: result, id: id});
  con.end();
  });
});

//get multiple amenities working
app.get('/airbnb/find-one', (request, response) => {
  let amenity = request.query.amenities;
  let minRoom = request.query.minBedrooms;
  let maxGuest =request.query.maxGuest;
  let maxPrice =request.query.MaxPrice;
  if(amenity == null)
  {
    amenity = 0;
  }
  queries.findListing(
    { 
      number_rooms: minRoom, 
      amenities : amenity
    }).then(result => {
      response.render("listing", {listing: result, maxGuest: maxGuest, maxPrice: maxPrice});
    });
});

app.get ("/airbnb/find-many", async (request, response) => {

  let numBed = request.query.bedrooms;
  let state = request.query.state;
  let city = request.query.city;

  queries.findListings(
    { 
      number_rooms: numBed,
    }).then(result => {
  response.render("listings", { listing: result, state: state, city: city, numBed: numBed});
  });
});